package com.example.dinnerdecider

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity() {
    
    val foodList = arrayListOf("Shawarma", "Pizza", "Hamburger", "McDonalds", "Pasta")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bdecider.setOnClickListener{
            val random = Random()
            val randomFood = random.nextInt(foodList.count())
            foodTxt.text = foodList[randomFood]
        }
        bAddFood.setOnClickListener{
            val newFood = et_AddFoodText.text.toString()
            foodList.add(newFood)
            et_AddFoodText.text.clear()
            println(foodList)
        }
    }
}